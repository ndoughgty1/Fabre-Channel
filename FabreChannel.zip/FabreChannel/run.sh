#!/bin/bash
#$ -V
#$ -cwd
#$ -N Fabre
#$ -pe mpi 16
#$ -l h_rt=24:00:00
#$ -M m.colombo@sheffield.ac.uk
#$ -m abe

mpirun -np 16 gemma -parallel >>log
