#$ -l h_rt=48:00:00
#$ -l nodes=1
#$ -cwd -V
#$ -m be

mpirun -np 40 gemma -parallel >> log
